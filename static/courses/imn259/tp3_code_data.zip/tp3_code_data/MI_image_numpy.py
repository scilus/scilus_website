
# MI_image_numpy.py — clean, commented, NumPy‑friendly 
# -----------------------------------------------------------------------------
# This module provides a very small image processing toolkit built on NumPy.
# It is designed to be approachable for first‑year undergraduates:
#   • Images are simple Python dicts with: 'width', 'height', 'channels', 'data'
#   • Pixel data lives in a NumPy array of shape (H, W, C) with float32 values
#   • Functions operate IN‑PLACE on that dict (unless otherwise stated)
#
#
# HOW TO READ THIS FILE:
#   1) Start with the “Image container helpers” section to see how images are
#      created and copied.
#   2) Look at “Point operations” (simple per‑pixel math).
#   3) Move to “Spatial filters” (median / average / gaussian, etc.).
#   4) Explore “Frequency domain (FFT)”.
#   5) Finally, “Feature detectors” (edges, corners) build on the basics above.
# -----------------------------------------------------------------------------

from __future__ import annotations

from typing import Dict
import numpy as np
import math

# -----------------------------------------------------------------------------
# Constants and file format helpers (PNM/PPM/PGM)
# -----------------------------------------------------------------------------
PGM_RAW = 0
PGM_ASCII = 1
PPM_RAW = 2
PPM_ASCII = 3

FILE_MAGIC_TO_FORMAT = {
    'P5': PGM_RAW,   # PGM (grayscale) binary
    'P2': PGM_ASCII, # PGM (grayscale) ASCII
    'P6': PPM_RAW,   # PPM (color RGB) binary
    'P3': PPM_ASCII  # PPM (color RGB) ASCII
}

def fatal_error(message: str):
    """Stop the program with a clear error message (used for input/shape checks)."""
    print(message)
    raise SystemExit(1)

# -----------------------------------------------------------------------------
# Image container helpers
# -----------------------------------------------------------------------------
def allocate_image(width: int, height: int, channels: int, dtype=np.float32) -> Dict:
    """Create a new image dict with a zero‑initialized data array.

    Parameters
    ----------
    width, height : image geometry (must be > 0)
    channels      : number of channels (1 = gray, 3 = RGB)
    dtype         : numpy dtype for the data buffer
    """
    if width <= 0 or height <= 0 or channels not in (1, 3):
        fatal_error('allocate_image: invalid')
    data = np.zeros((height, width, channels), dtype=dtype)
    return {'width': width, 'height': height, 'channels': channels, 'data': data}

def is_empty(img: Dict) -> bool:
    """Return True if an image dict looks uninitialized/invalid."""
    return (
        img is None or
        img.get('width', 0) <= 0 or
        img.get('height', 0) <= 0 or
        img.get('channels', 0) <= 0
    )

def same_size(a: Dict, b: Dict) -> bool:
    """Check if two images share the same geometry and channel count."""
    return (
        a['width'] == b['width'] and
        a['height'] == b['height'] and
        a['channels'] == b['channels']
    )

def clone_image(img: Dict) -> Dict:
    """Deep copy an image (preserve dtype)."""
    out = allocate_image(img['width'], img['height'], img['channels'], dtype=img['data'].dtype)
    out['data'][:] = img['data']
    return out

# Convenience pixel accessors (rarely needed in vectorized code but kept for API)
def get_color(img: Dict, x: int, y: int, z: int | None = None) -> float:
    return float(img['data'][y, x, 0 if z is None else z])

def set_color(img: Dict, val: float, x: int, y: int, z: int | None = None):
    img['data'][y, x, slice(None) if z is None else z] = float(val)

def get_color_flat(img: Dict, index: int, z: int) -> float:
    w = img['width']
    y = index // w
    x = index % w
    return float(img['data'][y, x, z])

def get_interpolated_color(img: Dict, x: float, y: float, z: int) -> float:
    H, W = img['height'], img['width']
    x1 = int(np.floor(x)); y1 = int(np.floor(y))
    x2 = min(x1 + 1, W - 1); y2 = min(y1 + 1, H - 1)
    x1 = max(0, x1); y1 = max(0, y1)

    fx = x - x1; fy = y - y1
    Q11 = img['data'][y1, x1, z]
    Q21 = img['data'][y1, x2, z]
    Q12 = img['data'][y2, x1, z]
    Q22 = img['data'][y2, x2, z]

    val1 = Q11 * (1 - fx) + Q21 * fx
    val2 = Q12 * (1 - fx) + Q22 * fx
    return float(val1 * (1 - fy) + val2 * fy)

# -----------------------------------------------------------------------------
# I/O (PNM/PGM/PPM) — DO NOT MODIFY LoadImage/SaveImage (verbatim copy)
# -----------------------------------------------------------------------------
def _read_pnm_header(f):
    magic = f.readline().strip(); magic = magic.decode('ascii') if isinstance(magic,bytes) else magic
    if magic not in FILE_MAGIC_TO_FORMAT: fatal_error('LoadImage Error: Unsupported file type')
    fmt = FILE_MAGIC_TO_FORMAT[magic]
    def next_token():
        token=[]
        while True:
            ch=f.read(1)
            if not ch: break
            if ch==b'#' or ch=='#': f.readline(); continue
            if (isinstance(ch,bytes) and ch.isspace()) or (isinstance(ch,str) and ch.isspace()):
                if token: break
                else: continue
            token.append(ch)
        if not token: return None
        bts=b''.join([c if isinstance(c,bytes) else c.encode('ascii') for c in token])
        return bts.decode('ascii')
    width=int(next_token()); height=int(next_token()); maxval=int(next_token())
    return magic,fmt,width,height,maxval

def LoadImage(file_name: str) -> Dict:
    if not file_name: fatal_error('Error: Please specify a filename')
    with open(file_name,'rb') as f:
        magic,fmt,width,height,maxval=_read_pnm_header(f)
        channels=1 if magic in ('P2','P5') else 3
        img=allocate_image(width,height,channels)
        if fmt==PGM_ASCII:
            with open(file_name,'r',encoding='ascii') as fa:
                line=fa.readline(); tokens=[]
                while len(tokens)<3:
                    line=fa.readline()
                    if not line: break
                    if line.strip().startswith('#'): continue
                    tokens.extend(line.strip().split())
                values=[]
                for line in fa:
                    if line.strip().startswith('#'): continue
                    values.extend(line.strip().split())
                arr=np.array(values,dtype=np.float32)
                if arr.size<width*height: fatal_error('PGM_ASCII: unexpected end of file')
                arr=arr[:width*height].reshape((height,width))
                img['data'][:,:,0]=arr*(255.0/maxval)
                return img
        elif fmt==PGM_RAW:
            raw=np.frombuffer(f.read(width*height),dtype=np.uint8)
            if raw.size<width*height: fatal_error('PGM_RAW: unexpected end of file')
            img['data'][:,:,0]=raw.reshape((height,width))*(255.0/maxval); return img
        elif fmt==PPM_ASCII:
            with open(file_name,'r',encoding='ascii') as fa:
                line=fa.readline(); tokens=[]
                while len(tokens)<3:
                    line=fa.readline()
                    if not line: break
                    if line.strip().startswith('#'): continue
                    tokens.extend(line.strip().split())
                values=[]
                for line in fa:
                    if line.strip().startswith('#'): continue
                    values.extend(line.strip().split())
                arr=np.array(values,dtype=np.float32); expected=width*height*3
                if arr.size<expected: fatal_error('PPM_ASCII: unexpected end of file')
                arr=arr[:expected].reshape((height,width,3))
                img['data'][:,:,:]=arr*(255.0/maxval); return img
        elif fmt==PPM_RAW:
            raw=np.frombuffer(f.read(width*height*3),dtype=np.uint8)
            if raw.size<width*height*3: fatal_error('PPM_RAW: unexpected end of file')
            img['data'][:,:,:]=raw.reshape((height,width,3))*(255.0/maxval); return img
        else: fatal_error('Unsupported format')

def SaveImage(img: Dict, file_name: str, ff: int):
    if not file_name: fatal_error('Error!! SaveImage')
    H,W,C=img['data'].shape; data_u8=np.clip(img['data'],0,255).astype(np.uint8)
    if ff==PGM_ASCII:
        with open(file_name,'w',encoding='ascii') as out:
            out.write(f"P2\n{W} {H}\n255\n");
            for y in range(H): out.write(' '.join(str(int(v)) for v in data_u8[y,:,0])+'\n')
    elif ff==PGM_RAW:
        with open(file_name,'wb') as out:
            out.write(f"P5\n{W} {H}\n255\n".encode('ascii')); out.write(data_u8[:,:,0].tobytes())
    elif ff==PPM_ASCII:
        with open(file_name,'w',encoding='ascii') as out:
            out.write(f"P3\n{W} {H}\n255\n"); arr=data_u8 if C>1 else np.repeat(data_u8[:,:,0:1],3,axis=2)
            for y in range(H):
                row_vals=arr[y].reshape(-1,3); out.write(' '.join(f"{int(r)} {int(g)} {int(b)}" for r,g,b in row_vals)+'\n')
    elif ff==PPM_RAW:
        with open(file_name,'wb') as out:
            out.write(f"P6\n{W} {H}\n255\n".encode('ascii')); arr=data_u8 if C>1 else np.repeat(data_u8[:,:,0:1],3,axis=2); out.write(arr.tobytes())
    else: fatal_error('save_image: unsupported FILE_FORMAT')

def SaveSpectralImage(img: Dict, file_name: str, ff: int, logTransform: bool):
    """Save the magnitude of a complex (real/imag) spectrum as a grayscale image.

    If `logTransform` is True, we visualize with a log scale to make details
    easier to see.
    """
    H, W, C = img['data'].shape
    Re = img['data'][:, :, 0]
    Im = img['data'][:, :, 1] if C > 1 else np.zeros_like(Re)
    mag = np.sqrt(Re*Re + Im*Im) / float(W*H)
    out = np.minimum(250.0*np.log(mag + 1.0), 255.0) if logTransform else np.minimum(mag, 255.0)
    tmp = allocate_image(W, H, 1)
    tmp['data'][:, :, 0] = out
    SaveImage(tmp, file_name, ff)

# -----------------------------------------------------------------------------
# Point operations (per‑pixel)
# -----------------------------------------------------------------------------
def Invert(img: Dict):
    """Invert intensities: x -> 255 - x (works for 1 or 3 channel data)."""
    img['data'][:] = 255.0 - img['data']

def Threshold(img: Dict, tvalue: float):
    """Binary thresholding using a per‑channel or luminance rule."""
    H, W, C = img['data'].shape
    if C > 1:
        mean = img['data'].mean(axis=2, keepdims=True)
        img['data'][:] = np.where(mean < tvalue, 0.0, 255.0)
    else:
        img['data'][:, :, 0] = np.where(img['data'][:, :, 0] < tvalue, 0.0, 255.0)

def Rescale(img: Dict):
    """Rescale each channel linearly to the full [0, 255] range.

    This is handy after filters that change the dynamic range (e.g., Laplacian).
    """
    H, W, C = img['data'].shape
    for ch in range(C):
        chd = img['data'][:, :, ch]
        mn = float(chd.min()); mx = float(chd.max())
        img['data'][:, :, ch] = (chd - mn) * 255.0 / (mx - mn + 1e-12)

def Average(img: Dict, channel: int = 0) -> float:
    """Return the mean intensity of a given channel."""
    return float(img['data'][:, :, channel].mean())

def Contrast(img: Dict, channel: int = 0) -> float:
    """Return the standard deviation (contrast) of a given channel."""
    return float(img['data'][:, :, channel].std(ddof=0))

def CyclRecal(img: Dict):
    """Multiply pixels by (-1)^(x+y) — a common step before some FFT ops."""
    H, W, C = img['data'].shape
    xx = np.arange(W)[None, :]
    yy = np.arange(H)[:, None]
    mask = ((-1.0) ** (xx + yy)).astype(img['data'].dtype)
    img['data'][:] = img['data'] * mask[:, :, None]

def WaveWarping(img: Dict, interp: int):
    """Apply a simple sinusoidal warp to the image.

    Parameters
    ----------
    interp : 0 for nearest‑neighbor, otherwise bilinear.
    """
    H, W, C = img['data'].shape
    out = allocate_image(W, H, C)
    x = np.arange(W)[None, :].astype(np.float32)
    y = np.arange(H)[:, None].astype(np.float32)

    i = np.clip(x + 10.0*np.sin(2*np.pi*y/100.0), 1.0, W-2.0)
    j = np.clip(y + 10.0*np.sin(2*np.pi*x/100.0), 1.0, H-2.0)

    for ch in range(C):
        if interp == 0:
            xi = (i + 0.5).astype(int)
            yj = (j + 0.5).astype(int)
            out['data'][:, :, ch] = img['data'][yj, xi, ch]
        else:
            x1 = np.floor(i).astype(int); y1 = np.floor(j).astype(int)
            x2 = np.clip(x1 + 1, 0, W-1); y2 = np.clip(y1 + 1, 0, H-1)
            fx = i - x1; fy = j - y1
            Q11 = img['data'][y1, x1, ch]
            Q21 = img['data'][y1, x2, ch]
            Q12 = img['data'][y2, x1, ch]
            Q22 = img['data'][y2, x2, ch]
            out['data'][:, :, ch] = (Q11*(1-fx) + Q21*fx)*(1-fy) + (Q12*(1-fx) + Q22*fx)*fy

    img['data'][:] = out['data']

def GammaCorrect(img: Dict, gamma: float):
    """Apply gamma correction (y = 255 * (x/255)^gamma)."""
    img['data'][:] = 255.0 * ((img['data'] / 255.0) ** gamma)

def ComputeHistogram(img: Dict, channel: int, norm: bool, hist: np.ndarray):
    """Compute a 256‑bin histogram for a channel. Result written to `hist`.

    If `norm` is True, histogram is normalized to sum to 1.
    """
    vals = np.clip(img['data'][:, :, channel], 0, 255).astype(np.int32)
    counts = np.bincount(vals.ravel(), minlength=256).astype(np.float32)
    hist[:] = counts
    if norm:
        hist[:] = hist / float(img['width'] * img['height'])

def HistogramEqualization(img: Dict):
    """Classic histogram equalization (grayscale)."""
    hist = np.zeros(256, dtype=np.float32)
    ComputeHistogram(img, 0, True, hist)
    cdf = np.cumsum(hist)
    idx = np.clip(img['data'][:, :, 0].astype(np.int32), 0, 255)
    img['data'][:, :, 0] = cdf[idx] * 255.0

def MatrixThreshold(img: Dict, matrix: Dict):
    """Threshold each pixel using a repeating small reference matrix."""
    if is_empty(matrix):
        fatal_error('Error!! MatrixThreshold')
    H, W, C = img['data'].shape
    Mh, Mw = matrix['height'], matrix['width']
    ref = matrix['data'][:, :, 0]
    for ch in range(C):
        comp = img['data'][:, :, ch]
        thresh = ref[np.mod(np.arange(H)[:, None], Mh), np.mod(np.arange(W)[None, :], Mw)]
        img['data'][:, :, ch] = np.where(comp > thresh, 255.0, 0.0)

def RGBToGray(img: Dict):
    """Convert an RGB image to grayscale by averaging channels (in‑place)."""
    if img['channels'] <= 1:
        return
    gray = img['data'].mean(axis=2, keepdims=True)
    img['data'] = np.concatenate([gray], axis=2)
    img['channels'] = 1

def Abs(img: Dict):
    """Absolute value (per pixel)."""
    img['data'][:] = np.abs(img['data'])

def TemporalMedianFilter(img_list: list[Dict], nbImages: int) -> Dict:
    """Return the per‑pixel median across the first `nbImages` images.

    This returns a NEW image (does not modify inputs).
    """
    stack = np.stack([im['data'] for im in img_list[:nbImages]], axis=0)
    med = np.median(stack, axis=0)
    out = clone_image(img_list[0])
    out['data'][:] = med
    return out

# -----------------------------------------------------------------------------
# Spatial filtering helpers and filters (convolutions, windows)
# -----------------------------------------------------------------------------
from numpy.lib.stride_tricks import sliding_window_view
    
def MedianFilter(img: Dict, halfwinsize: int):
    #TODO
    
def AverageFilter(img: Dict, halfwinsize: int):
    #TODO
    
def Gaussian2D(x: float, y: float, stddev: float) -> float:
    #TODO

def LowpassGaussianFilter(img: Dict, sigma: float):
    #TODO
    
def HighpassGaussianFilter(img: Dict, sigma: float):
    #TODO

def CorrelationFilter(img: Dict, corrImg: Dict):
    #TODO
    
def RescaledCorrelationFilter(img: Dict, corrImg: Dict):
    #TODO
    
# -----------------------------------------------------------------------------
# Frequency domain (FFT)
# -----------------------------------------------------------------------------
def FFT(img: Dict):
    #TODO
    
def IFFT(img: Dict):
    # TODO
    
def SpectralIdealLowPassFilter(img: Dict, radius: float):
    #TODO
    
def SpectralIdealHighPassFilter(img: Dict, radius: float):
    #TODO
    
def SpectralRectLowPassFilter(img: Dict, radius: float):
    # TODO

def SpectralRectHighPassFilter(img: Dict, radius: float):
    # TODO

def SpectralAverageFilter(img: Dict, halfwinsize: int):
    # TODO
    
def SpectralCorrelationFilter(img: Dict, corrImg: Dict):
    # TODO
