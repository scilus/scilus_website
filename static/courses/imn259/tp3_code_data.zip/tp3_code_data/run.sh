###############################################################
# Ceci n'est qu'un exemple. Pas obligé de suivre exactement.  #
# Ça vous donne une idée à quoi ressemble mes solutions.      #
###############################################################

# A - filtre moyenneur sur Barbara
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3A 2
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3A 5

# B - filtre passe-bas Gaussien sur Barbara
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3B 1.0
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3B 3.0

# C - filtre passe-haut Gaussien sur Barbara
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3C 2.0
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3C 5

# D - filtrage frequentiel passe-bas dans une fenetre NxN
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3D_low 10 --tp3D_save_spectrum
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3D_low 50 --tp3D_save_spectrum

# D - passe-haut
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3D_high 50 --tp3D_save_spectrum
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3D_high 10 --tp3D_save_spectrum
  
# E - median filter sur Barbara
python tp3.py --input images/saltPepperImage.ppm --outdir ./tp3_out --tp3E 1
python tp3.py --input images/saltPepperImage.ppm --outdir ./tp3_out --tp3E 5

# F - correlation en noir et blanc
python tp3.py --input images/letters.pgm --outdir ./tp3_out --tp3F images/correlationImage.pgm
# F - correlation en couleur
python tp3.py --input images/letters.ppm --outdir ./tp3_out --tp3F images/correlationImage.ppm

# G - correlation recalee entre 2 images
python tp3.py --input images/barbara.pgm --outdir ./tp3_out --tp3F images/nose.pgm
python tp3.py --input images/olives.pgm --outdir ./tp3_out --tp3F images/corrOlive.pgm
python tp3.py --input images/olives.ppm --outdir ./tp3_out --tp3F images/corrOlive.ppm


