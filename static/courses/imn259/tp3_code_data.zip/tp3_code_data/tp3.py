#!/usr/bin/env python3
# TP3 CLI dispatcher for IMN259 — runs tp3A … tp3G using MI_image_numpy.py
# -------------------------------------------------------------------------
# Tasks (from the TP handout):
#  - tp3A: Average (box) filter
#  - tp3B: Gaussian low-pass (spatial)
#  - tp3C: Gaussian high-pass (spatial)
#  - tp3D: Frequency-domain rectangular low-pass / high-pass (via FFT)
#  - tp3E: Median filter
#  - tp3F: Correlation (spatial)
#  - tp3G: Normalized (re-scaled) correlation (spatial)
#
# Notes:
#  * SaveImage/LoadImage are used as-is; outputs use .pgm (gray) or .ppm (RGB).
#  * For tp3D we follow: FFT -> spectral filter(s) -> IFFT -> Rescale.
# -------------------------------------------------------------------------

import os
import argparse
from MI_image_numpy import (
    LoadImage, SaveImage, PGM_RAW, PPM_RAW,  # I/O
    Rescale, RGBToGray,                      # utilities
    AverageFilter, LowpassGaussianFilter, HighpassGaussianFilter,
    MedianFilter, CorrelationFilter, RescaledCorrelationFilter,
    FFT, IFFT, SaveSpectralImage,
    SpectralRectLowPassFilter, SpectralRectHighPassFilter, CyclRecal
)

import numpy as np

# ---------- helpers ----------

def ensure_outdir(path: str):
    os.makedirs(path, exist_ok=True)

def _pick_ext(fmt, img):
    """Choose .pgm for grayscale, .ppm for RGB."""
    if fmt == PGM_RAW or (fmt is None and img['channels'] == 1):
        return ".pgm"
    if fmt == PPM_RAW or (fmt is None and img['channels'] == 3):
        return ".ppm"
    return ".pnm"

def save_step(img, outdir, stem, fmt=None):
    """
    Save with format-aware extension. If fmt is None, infer from channels.
    """
    #TODO
    
# ---------- CLI ----------

def build_parser():
    p = argparse.ArgumentParser(
        description="TP3 runner (IMN259) — applies filters from MI_image_numpy.py"
    )
    p.add_argument("--input", required=True, help="Input image (PGM/PPM: P2/P5/P3/P6)")
    p.add_argument("--outdir", default="./tp3_out", help="Output directory")
    p.add_argument("--rgb2gray", action="store_true", help="Convert to grayscale before processing")

    # tp3A
    p.add_argument("--tp3A", type=int, metavar="HALF",
                   help="Average filter with half window size HALF (e.g., 2 -> window 5x5)")

    # tp3B
    p.add_argument("--tp3B", type=float, metavar="SIGMA",
                   help="Gaussian low-pass (spatial) with standard deviation SIGMA (kernel ~ 6σ+1)")

    # tp3C
    p.add_argument("--tp3C", type=float, metavar="SIGMA",
                   help="Gaussian high-pass (spatial) with standard deviation SIGMA")

    # tp3D
    p.add_argument("--tp3D_low", type=float, metavar="R",
                   help="Frequency-domain rectangular low-pass cutoff parameter R")
    p.add_argument("--tp3D_high", type=float, metavar="R",
                   help="Frequency-domain rectangular high-pass cutoff parameter R")
    p.add_argument("--tp3D_save_spectrum", action="store_true",
                   help="Also save spectrum images for tp3D (before/after masking)")

    # tp3E
    p.add_argument("--tp3E", type=int, metavar="HALF",
                   help="Median filter with half window size HALF")

    # tp3F
    p.add_argument("--tp3F", metavar="KERNEL_IMG",
                   help="Spatial correlation with kernel image (PGM/PPM). Will Rescale the result.")

    # tp3G
    p.add_argument("--tp3G", metavar="KERNEL_IMG",
                   help="Re-scaled (normalized) spatial correlation with kernel image. Will Rescale the result.")

    return p

# ---------- tasks ----------

def run_tp3A(img, outdir, half):
    """Average (box) filter."""
    #TODO

def run_tp3B(img, outdir, sigma):
    """Gaussian low-pass (spatial)."""
    LowpassGaussianFilter(img, sigma)
    save_step(img, outdir, f"tp3B_lowpass_gauss_sigma{sigma:g}")

def run_tp3C(img, outdir, sigma):
    """Gaussian high-pass (spatial)."""
    #TODO

def run_tp3D(img, outdir, r_low, r_high, save_spectrum=False):
    """
    Frequency-domain rectangular low/high-pass.

    Pipeline:
        CyclRecal (center DC) -> FFT -> apply rectangular masks (centered)
        -> [optional SaveSpectralImage previews] -> IFFT -> CyclRecal (uncenter) -> Rescale

    Parameters
    ----------
    r_low : float | None
        Half-size (in pixels) of the low-pass rectangle. A square region of size (2*r_low+1)^2
        centered at (W/2, H/2) is kept; outside is zeroed.
    r_high : float | None
        Half-size (in pixels) of the high-pass rectangle. A square region of size (2*r_high+1)^2
        centered at (W/2, H/2) is suppressed; outside is kept.
    """
    #TODO

    
def run_tp3E(img, outdir, half):
    """Median filter."""
    #TODO

def run_tp3F(img, outdir, kernel_path):
    """Spatial correlation: f ⊗ h. Then rescale for visualization."""
    #TODO

    def run_tp3G(img, outdir, kernel_path):
    """Re-scaled (normalized) spatial correlation, then Rescale for visualization."""
    #TODO
    
# ---------- main ----------

def main():
    args = build_parser().parse_args()
    ensure_outdir(args.outdir)

    img = LoadImage(args.input)
    # Save initial input (for traceability)
    save_step(img, args.outdir, "00_input", fmt=(PGM_RAW if img['channels']==1 else PPM_RAW))

    if args.rgb2gray and img['channels'] > 1:
        RGBToGray(img)
        save_step(img, args.outdir, "00a_gray", fmt=PGM_RAW)

    # Run selected tasks in the order A..G if provided
    if args.tp3A is not None:
        run_tp3A(img, args.outdir, args.tp3A)

    if args.tp3B is not None:
        run_tp3B(img, args.outdir, args.tp3B)

    if args.tp3C is not None:
        run_tp3C(img, args.outdir, args.tp3C)

    if args.tp3D_low is not None or args.tp3D_high is not None:
        run_tp3D(img, args.outdir, args.tp3D_low, args.tp3D_high, args.tp3D_save_spectrum)

    if args.tp3E is not None:
        run_tp3E(img, args.outdir, args.tp3E)

    if args.tp3F is not None:
        run_tp3F(img, args.outdir, args.tp3F)

    if args.tp3G is not None:
        run_tp3G(img, args.outdir, args.tp3G)

    print("Done.")

if __name__ == "__main__":
    main()
