
for i in images/*;
do
    echo $i
    python3 tp1.py $i
done



