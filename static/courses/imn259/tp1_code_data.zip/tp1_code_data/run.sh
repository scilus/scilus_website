
for i in images/*;
do
    echo $i
    python3 tp1.py $i
done

mkdir -p out
mv *ppm out/




