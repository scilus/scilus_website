#
# Citez vos sources
# Comprenez vos codes
#

# TP2 #1
python tp2.py warp --help
mkdir -p out_warp out_gamma
for i in images/*{pgm,ppm};
do
    echo $i;
    stem=${i/images\//};
   
    python tp2.py warp --input $i \
	   --output0 out_warp/${stem}_0.ppm --output1 out_warp/${stem}_1.ppm
done


# TP2 #2
python tp2.py snr --help 
python tp2.py snr --input images/whiteSquare.pgm -N 64 --noise-type gaussian


# TP2 #3
python tp2.py median --help
mkdir -p out_median_temporal
python tp2.py median --list videoFiles.txt \
       --median-out out_median_temporal/outTemporalMedianImage.ppm \
       --frame-prefix out_median_temporal/outVideoFile_ \
       --threshold 25






