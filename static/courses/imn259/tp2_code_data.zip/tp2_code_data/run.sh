#
# Citez vos sources
# Comprenez vos codes
#

python tp2.py --help

# TP2 #1
python tp2.py histeq --help
mkdir -p out_histeq
for i in images/*pgm;
do
    echo $i;
    stem=${i/images\//};    
    python tp2.py histeq --input $i --output out_histeq/${stem}.pgm
done


# TP2 #2 et #3
python tp2.py warp --help
python tp2.py gamma --help
mkdir -p out_warp out_gamma
for i in images/*{pgm,ppm};
do
    echo $i;
    stem=${i/images\//};
   
    python tp2.py warp --input $i \
	   --output0 out_warp/${stem}_0.ppm --output1 out_warp/${stem}_1.ppm
    python tp2.py gamma --input $i --gamma 1.8 --output out_gamma/${stem}_1.8.ppm
    python tp2.py gamma --input $i --gamma 0.5 --output out_gamma/${stem}_0.5.ppm
done

# TP2 #4
python tp2.py median --help
mkdir -p out_median_temporal
python tp2.py median --list videoFiles.txt \
       --median-out out_median_temporal/outTemporalMedianImage.ppm \
       --frame-prefix out_median_temporal/outVideoFile_ \
       --threshold 25


#
# Remettez-moi vos codes, dossiers d'input et output 
#
 





