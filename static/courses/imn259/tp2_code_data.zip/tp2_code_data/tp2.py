#!/usr/bin/env python3
"""
TP2 Python script using MI_image_numpy.py (PGM/PPM only)

Subcommands:
- histeq  : Histogram equalization (tp2 #1)
- warp    : Wave warping (tp2 #2p), saves nearest and bilinear outputs
- gamma   : Gamma correction (tp2 #3)
- median  : Temporal median pipeline (tp2 #4)
"""

import argparse
#from MI_image import ( ... )


# -------- CLI (Command-Line Interface)--------
def make_parser():
    p = argparse.ArgumentParser(description='TP2 using MI_image_numpy.py')
    sub = p.add_subparsers(dest='cmd', required=True)
    # gamma
    pg = sub.add_parser('gamma', help='Gamma correction')
    pg.add_argument('--input', required=True, help='Input image (PGM/PPM)')
    pg.add_argument('--gamma', required=True, type=float, help='Gamma value (e.g., 0.5, 1.8)')
    pg.add_argument('--output', default='outGammaCorrected.ppm', help='Output PPM (default: outGammaCorrected.ppm)')
    # median
    pt = sub.add_parser('median', help='Temporal median pipeline')
    pt.add_argument('--list', required=True, help='Text file: first token = nbImages, then nbImages paths')
    pt.add_argument('--median-out', default='outTemporalMedianImage.ppm', help='Output PPM for median image')
    pt.add_argument('--frame-prefix', default='outVideoFile_', help='Prefix for per-frame output PGM files')
    pt.add_argument('--threshold', type=float, default=25.0, help='Threshold value (default: 25)')
    # histeq
    pa = sub.add_parser('histeq', help='Histogram equalization (grayscale output)')
    pa.add_argument('--input', required=True, help='Input image (PGM/PPM)')
    pa.add_argument('--output', default='outHistEq.pgm', help='Output PGM (default: outHistEq.pgm)')
    # warp
    pb = sub.add_parser('warp', help='Wave warping (nearest and bilinear)')
    pb.add_argument('--input', required=True, help='Input image (PGM/PPM)')
    pb.add_argument('--output0', default='outWarping0.ppm', help='Output PPM for nearest neighbor warping')
    pb.add_argument('--output1', default='outWarping1.ppm', help='Output PPM for bilinear warping')
    return p


def main():
    args = make_parser().parse_args()
    if args.cmd == 'gamma':
        gamma_correction(args.input, args.gamma, args.output)
    elif args.cmd == 'median':
        temporal_median_pipeline(args.list, args.median_out, args.frame_prefix, args.threshold)
    elif args.cmd == 'histeq':
        hist_eq(args.input, args.output)
    elif args.cmd == 'warp':
        warp_both(args.input, args.output0, args.output1)

if __name__ == '__main__':
    main()


    
