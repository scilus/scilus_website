#!/usr/bin/env python3
"""
Minimal NumPy-based image utilities required by tp2.py.

Supported formats: PGM/PPM (ASCII P2/P3 and RAW P5/P6).
"""
import numpy as np
from typing import Dict

# ------------------------------
# I/O: Load and Save PNM (PGM/PPM)
# ------------------------------
def LoadImage( ... ):
    # TP1
    return None

def SaveImage( ... ): 
    # VOTRE TP1
    return None

# ------------------------------
# Operations suggested for tp2.py
# ------------------------------
def TemporalMedianFilter( ... ):
    #TODO
    return img

def ComputeHistogram( ... ):
    #TODO
    return img

def HistogramEqualization( ... ):
    #TODO
    return img

def WaveWarping( ... ):
    #TODO
    return img

def add_noise( ... ):
    return img

def SNR( ... ): # SNR experiment 
    # TODO
    return None

