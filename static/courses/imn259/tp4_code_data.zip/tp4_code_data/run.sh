python tp4.py -h

# A: Gradient magnitude threshold
# le choix du sigma et threshold est important
python tp4.py --tp4A --threshold 40 --sigma 1.0 --input images/form.pgm 

# B: Zero-crossing (Laplacian + filtering)
# le choix du sigma et threshold est important
python tp4.py --tp4B --threshold 10  --sigma 1.0 --input images/shapes.pgm


# C: Non-maximum suppression
python tp4.py --tp4C --sigma 1.0 --input images/cameramanNoise.pgm

# D: Harris corner detection
python tp4.py --tp4D --halfwinsize 3 --k 0.04 --input images/clown.pgm

# E: K-means segmentation (K=2)
python tp4.py --tp4Ea --input images/form.pgm
python tp4.py --tp4Eb 3 --input images/satelliteIles.pgm

