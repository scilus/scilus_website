for i in *.pgm;
do
    python demo_bruit.py $i
done

python3 demo_snr.py whiteSquare.pgm

