#!/usr/bin/env python3
"""
Usage: python3 demo_snr.py whiteSquare.pgm
"""

import sys
import matplotlib.pyplot as plt
import numpy as np

from PIL import Image
from pathlib import Path
from MI_image import load_image

# trouve le nom de fichier sans l'extension et sans le path vers le fichier
in_path = Path(sys.argv[1])    
stem = in_path.stem        
img, N, M, c = load_image(str(in_path))
print(stem, N, M, c)

# on met l'image entre 0 et 1 
img = img.astype(np.float64) / 255.0
# bruit centré entre -1 et 1
sigma = 0.2
# ici on pourrait appeler la fonction random.normal pour un bruit Gaussien
noise = (np.random.rand(img.shape[0], img.shape[1])-0.5)*2
# version pas centré
#noise = np.random.rand(img.shape[0], img.shape[1])
img_bruit = (img + sigma*noise)

from snr import snr
print("SNR de l'image:", stem, snr(img, img_bruit))

# Calcule du SNR en pratique
# moyenne du signal / ecart type du bruit
print(img == 1)
plt.imshow(img == 1)
plt.show()
mean_value = img_bruit[img == 1].mean()
std_value = img_bruit[img == 0].std()
print("Mean:", mean_value)
print("Std:", std_value)
print("SNR approximé", mean_value / std_value)
