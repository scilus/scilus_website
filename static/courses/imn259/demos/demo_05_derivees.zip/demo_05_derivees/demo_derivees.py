import sys
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import convolve2d

from MI_image import load_image
from pathlib import Path

in_path = Path(sys.argv[1])    
stem = in_path.stem        
img, N, M, c = load_image(str(in_path))
print(stem, N, M, c)

# Derivée d'ordre 1 par différences finies
# centrale
filtre_g = [[-1 / 2, 0, 1 / 2]]
I_x_centered = convolve2d(img, np.array(filtre_g).T)
I_y_centered = convolve2d(img, filtre_g)
# avant (forward en anglais)
filtre_g = [[0, -1, 1]]
I_x_fwd = convolve2d(img, np.array(filtre_g).T)
I_y_fwd = convolve2d(img, filtre_g)
# arrière (backward en anglais)
filtre_g = [[-1, 1, 0]]
I_x_bwd = convolve2d(img, np.array(filtre_g).T)
I_y_bwd = convolve2d(img, filtre_g)

fig, axes = plt.subplots(3, 2)
# Flatten axes array for easy iteration
axes = axes.flatten()

axes[0].imshow(I_x_centered, cmap='gray')
axes[0].set_title('Gradient centré, axe x')
axes[1].imshow(I_y_centered,  cmap='gray')
axes[1].set_title('Gradient centré, axe y')
axes[2].imshow(I_x_fwd, cmap='gray')
axes[2].set_title('Gradient avant, axe x')
axes[3].imshow(I_y_fwd,  cmap='gray')
axes[3].set_title('Gradient avant, axe y')
axes[4].imshow(I_x_bwd, cmap='gray')
axes[4].set_title('Gradient arrière, axe x')
axes[5].imshow(I_y_bwd,  cmap='gray')
axes[5].set_title('Gradient arrière, axe y')
plt.tight_layout()
plt.show()


# Derivée d'ordre 2 par différences finies
# centrale
filtre_g = [[1/4, 0, -1/4],
            [0,   0, 0],
            [-1/4,0, 1/4]]
I_xy = convolve2d(img, filtre_g)
filtre_g = [[1, 0, -2, 0, 1]]
I_xx = convolve2d(img, np.array(filtre_g).T)
I_yy = convolve2d(img, filtre_g)

fig, axes = plt.subplots(1, 3)
# Flatten axes array for easy iteration
axes = axes.flatten()

axes[0].imshow(I_xx, cmap='gray')
axes[0].set_title('Dérivée d ordre 2 centré, en xx')
axes[1].imshow(I_yy,  cmap='gray')
axes[1].set_title('Dérivée d ordre 2 centré, en yy')
axes[2].imshow(I_xy, cmap='gray')
axes[2].set_title('Dérivée d ordre 2, en xy')
plt.tight_layout()
plt.show()





