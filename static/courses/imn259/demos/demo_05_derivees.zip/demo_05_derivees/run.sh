python demo_derivees.py form.pgm
python demo_derivees.py clown.pgm
