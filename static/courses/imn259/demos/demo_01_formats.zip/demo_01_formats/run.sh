
for i in *.{pgm,ppm};
do
    python demo_format_load.py $i
done
