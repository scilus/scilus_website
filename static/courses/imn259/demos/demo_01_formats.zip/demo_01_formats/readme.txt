Ouvrez les fichiers images dans un editeur texte pour voir le contenu de l'image.
Les diapos les expliquent bien aussi.
Voir le code et données du TP1 pour voir du code Python qui charge
chaque image et affiche sa taille et le nombre de channels.
