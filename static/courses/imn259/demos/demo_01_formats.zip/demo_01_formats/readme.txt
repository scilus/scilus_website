Ouvrez les fichiers images dans un editeur texte pour voir le contenu de l'image.
Les diapos les expliquent bien aussi.

