#!/usr/bin/env python3
"""
Usage: python3 demo_format_load.py <input.pgm|ppm>
"""

import sys
import matplotlib.pyplot as plt
import numpy as np

from pathlib import Path
from MI_image import load_image

# trouve le nom de fichier sans l'extension et sans le path vers le fichier
in_path = Path(sys.argv[1])    
stem = in_path.stem        
img, N, M, c = load_image(str(in_path))
print(stem, N, M, c)

# SAVE et plus dans le TP1







    

    



