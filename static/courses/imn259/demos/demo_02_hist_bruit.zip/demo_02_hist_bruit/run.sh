
for i in *.{pgm,ppm};
do
    python demo_hist.py $i
done

for i in *.pgm;
do
    python demo_bruit.py $i
done


