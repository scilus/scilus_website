#!/usr/bin/env python3
"""
Usage: python3 demo_bruit.py <input.pgm|ppm>
"""

import sys
import matplotlib.pyplot as plt
import numpy as np

from pathlib import Path
from MI_image import load_image

# trouve le nom de fichier sans l'extension et sans le path vers le fichier
in_path = Path(sys.argv[1])    
stem = in_path.stem        
img, N, M, c = load_image(str(in_path))
print(stem, N, M, c)

# Quelques operations ponctuelles simples en python
plt.title('Image')
plt.imshow(img)
plt.show()

# on met l'image entre 0 et 1 
img_bruit = img.astype(np.float64) / 255.0
# bruit centré entre -1 et 1
sigma = 0.2
noise = (np.random.rand(img.shape[0], img.shape[1])-0.5)*2
img_bruit = img_bruit + sigma*noise

plt.title('Image bruitée')
plt.imshow(img_bruit)
plt.show()



    





    

    



