
python tp2.py median --help
mkdir -p out_median_temporal

python tp2.py median --list videoFiles.txt \
       --median-out out_median_temporal/outTemporalMedianImage.ppm \
       --frame-prefix out_median_temporal/outVideoFile_ \
       --threshold 25

