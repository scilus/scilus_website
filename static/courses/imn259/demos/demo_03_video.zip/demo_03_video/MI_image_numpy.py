#!/usr/bin/env python3
"""
Minimal NumPy-based image utilities required by tp2.py.

Supported formats: PGM/PPM (ASCII P2/P3 and RAW P5/P6).
"""

import numpy as np
from typing import Dict

# ------------------------------
# Constants and format mapping
# ------------------------------
PGM_RAW = 0
PGM_ASCII = 1
PPM_RAW = 2
PPM_ASCII = 3

FILE_MAGIC_TO_FORMAT = {
    'P5': PGM_RAW,
    'P2': PGM_ASCII,
    'P6': PPM_RAW,
    'P3': PPM_ASCII,
}


# ------------------------------
# Core helpers
# ------------------------------

def fatal_error(message: str) -> None:
    print(message)
    raise SystemExit(1)


def allocate_image(width: int,
                   height: int,
                   channels: int,
                   dtype=np.float32) -> Dict:
    if width <= 0 or height <= 0 or channels not in (1, 3):
        fatal_error('allocate_image: invalid')
    data = np.zeros((height, width, channels), dtype=dtype)
    return {
        'width': width,
        'height': height,
        'channels': channels,
        'data': data,
    }


def same_size(a: Dict, b: Dict) -> bool:
    return (a['width'] == b['width'] and
            a['height'] == b['height'] and
            a['channels'] == b['channels'])


def clone_image(img: Dict) -> Dict:
    out = allocate_image(img['width'],
                         img['height'],
                         img['channels'],
                         dtype=img['data'].dtype)
    out['data'][:] = img['data']
    return out


# ------------------------------
# I/O: Load and Save PNM (PGM/PPM)
# ------------------------------

def _read_pnm_header(f):
    """Read magic + width + height + maxval, skipping '#' comments."""
    magic = f.readline().strip()
    magic = magic.decode('ascii') if isinstance(magic, bytes) else magic
    if magic not in FILE_MAGIC_TO_FORMAT:
        fatal_error('LoadImage Error: Unsupported file type')
    fmt = FILE_MAGIC_TO_FORMAT[magic]

    def next_token():
        token = []
        while True:
            ch = f.read(1)
            if not ch:
                break
            if ch == b'#' or ch == '#':
                f.readline()
                continue
            is_space = (ch.isspace() if isinstance(ch, str)
                        else ch.isspace())
            if is_space:
                if token:
                    break
                continue
            token.append(ch)
        if not token:
            return None
        bts = b''.join(c if isinstance(c, bytes)
                       else c.encode('ascii') for c in token)
        return bts.decode('ascii')

    width = int(next_token())
    height = int(next_token())
    maxval = int(next_token())
    return magic, fmt, width, height, maxval


def LoadImage(file_name: str) -> Dict:
    if not file_name:
        fatal_error('Error: Please specify a filename')

    with open(file_name, 'rb') as f:
        magic, fmt, width, height, maxval = _read_pnm_header(f)
        channels = 1 if magic in ('P2', 'P5') else 3
        img = allocate_image(width, height, channels)

        if fmt == PGM_ASCII:
            # reopen as text to stream integers
            with open(file_name, 'r', encoding='ascii') as fa:
                # skip header lines and comments
                line = fa.readline()
                tokens = []
                while len(tokens) < 3:
                    line = fa.readline()
                    if not line:
                        break
                    if line.strip().startswith('#'):
                        continue
                    tokens.extend(line.strip().split())
                values = []
                for line in fa:
                    if line.strip().startswith('#'):
                        continue
                    values.extend(line.strip().split())
                arr = np.array(values, dtype=np.float32)
                need = width * height
                if arr.size < need:
                    fatal_error('PGM_ASCII: unexpected end of file')
                arr = arr[:need].reshape((height, width))
                img['data'][:, :, 0] = arr * (255.0 / maxval)
            return img

        if fmt == PGM_RAW:
            raw = np.frombuffer(f.read(width * height), dtype=np.uint8)
            if raw.size < width * height:
                fatal_error('PGM_RAW: unexpected end of file')
            img['data'][:, :, 0] = raw.reshape((height, width)) * (
                255.0 / maxval
            )
            return img

        if fmt == PPM_ASCII:
            with open(file_name, 'r', encoding='ascii') as fa:
                line = fa.readline()
                tokens = []
                while len(tokens) < 3:
                    line = fa.readline()
                    if not line:
                        break
                    if line.strip().startswith('#'):
                        continue
                    tokens.extend(line.strip().split())
                values = []
                for line in fa:
                    if line.strip().startswith('#'):
                        continue
                    values.extend(line.strip().split())
                arr = np.array(values, dtype=np.float32)
                need = width * height * 3
                if arr.size < need:
                    fatal_error('PPM_ASCII: unexpected end of file')
                arr = arr[:need].reshape((height, width, 3))
                img['data'][:, :, :] = arr * (255.0 / maxval)
            return img

        if fmt == PPM_RAW:
            raw = np.frombuffer(f.read(width * height * 3), dtype=np.uint8)
            if raw.size < width * height * 3:
                fatal_error('PPM_RAW: unexpected end of file')
            img['data'][:, :, :] = raw.reshape((height, width, 3)) * (
                255.0 / maxval
            )
            return img

        fatal_error('Unsupported format')


def SaveImage(img: Dict, file_name: str, ff: int) -> None:
    if not file_name:
        fatal_error('Error!! SaveImage')

    H, W, C = img['data'].shape
    data_u8 = np.clip(img['data'], 0, 255).astype(np.uint8)

    if ff == PGM_ASCII:
        with open(file_name, 'w', encoding='ascii') as out:
            out.write(f"P2\n{W} {H}\n255\n")
            for y in range(H):
                row = ' '.join(str(int(v)) for v in data_u8[y, :, 0])
                out.write(row + "\n")
        return

    if ff == PGM_RAW:
        with open(file_name, 'wb') as out:
            out.write(f"P5\n{W} {H}\n255\n".encode('ascii'))
            out.write(data_u8[:, :, 0].tobytes())
        return

    if ff == PPM_ASCII:
        with open(file_name, 'w', encoding='ascii') as out:
            out.write(f"P3\n{W} {H}\n255\n")
            arr = (data_u8 if C > 1 else
                   np.repeat(data_u8[:, :, 0:1], 3, axis=2))
            for y in range(H):
                row_vals = arr[y].reshape(-1, 3)
                row = ' '.join(
                    f"{int(r)} {int(g)} {int(b)}"
                    for r, g, b in row_vals
                )
                out.write(row + "\n")
        return

    if ff == PPM_RAW:
        with open(file_name, 'wb') as out:
            out.write(f"P6\n{W} {H}\n255\n".encode('ascii'))
            arr = (data_u8 if C > 1 else
                   np.repeat(data_u8[:, :, 0:1], 3, axis=2))
            out.write(arr.tobytes())
        return

    fatal_error('save_image: unsupported FILE_FORMAT')


# ------------------------------
# Operations required by tp2.py
# ------------------------------

def GammaCorrect(img: Dict, gamma: float) -> None:
    img['data'][:] = 255.0 * ((img['data'] / 255.0) ** gamma)


def TemporalMedianFilter(img_list: list[Dict],
                         nb_images: int) -> Dict:
    stack = np.stack([im['data'] for im in img_list[:nb_images]], axis=0)
    med = np.median(stack, axis=0)
    out = clone_image(img_list[0])
    out['data'][:] = med
    return out


def subtract_inplace(img: Dict, other: Dict) -> None:
    if not same_size(img, other):
        return
    img['data'][:] = img['data'] - other['data']


def Abs(img: Dict) -> None:
    img['data'][:] = np.abs(img['data'])


def RGBToGray(img: Dict) -> None:
    if img['channels'] <= 1:
        return
    gray = img['data'].mean(axis=2, keepdims=True)
    img['data'] = np.concatenate([gray], axis=2)
    img['channels'] = 1


def Threshold(img: Dict, tvalue: float) -> None:
    H, W, C = img['data'].shape
    if C > 1:
        mean = img['data'].mean(axis=2, keepdims=True)
        img['data'][:] = np.where(mean < tvalue, 0.0, 255.0)
    else:
        plane = img['data'][:, :, 0]
        img['data'][:, :, 0] = np.where(plane < tvalue, 0.0, 255.0)


def ComputeHistogram(img: Dict,
                     channel: int,
                     norm: bool,
                     hist: np.ndarray) -> None:
    vals = np.clip(img['data'][:, :, channel], 0, 255).astype(np.int32)
    counts = np.bincount(vals.ravel(), minlength=256).astype(np.float32)
    hist[:] = counts
    if norm:
        total = img['width'] * img['height']
        hist[:] = hist / float(total)


def HistogramEqualization(img: Dict) -> None:
    hist = np.zeros(256, dtype=np.float32)
    ComputeHistogram(img, 0, True, hist)
    cdf = np.cumsum(hist)
    idx = np.clip(img['data'][:, :, 0].astype(np.int32), 0, 255)
    img['data'][:, :, 0] = cdf[idx] * 255.0


def WaveWarping(img: Dict, interp: int) -> None:
    H, W, C = img['data'].shape
    out = allocate_image(W, H, C)

    x = np.arange(W)[None, :].astype(np.float32)
    y = np.arange(H)[:, None].astype(np.float32)

    i = np.clip(x + 10.0 * np.sin(2 * np.pi * y / 100.0), 1.0, W - 2.0)
    j = np.clip(y + 10.0 * np.sin(2 * np.pi * x / 100.0), 1.0, H - 2.0)

    for ch in range(C):
        if interp == 0:
            xi = (i + 0.5).astype(int)
            yj = (j + 0.5).astype(int)
            out['data'][:, :, ch] = img['data'][yj, xi, ch]
        else:
            x1 = np.floor(i).astype(int)
            y1 = np.floor(j).astype(int)
            x2 = np.clip(x1 + 1, 0, W - 1)
            y2 = np.clip(y1 + 1, 0, H - 1)
            fx = i - x1
            fy = j - y1

            Q11 = img['data'][y1, x1, ch]
            Q21 = img['data'][y1, x2, ch]
            Q12 = img['data'][y2, x1, ch]
            Q22 = img['data'][y2, x2, ch]

            out['data'][:, :, ch] = (
                (Q11 * (1.0 - fx) + Q21 * fx) * (1.0 - fy) +
                (Q12 * (1.0 - fx) + Q22 * fx) * fy
            )

    img['data'][:] = out['data']


def add_gaussian_noise(img, sigma = 20, clip=True, rng=None):
    """
    Add zero-mean Gaussian noise with std=sigma to an image.

    Parameters
    ----------
    img : np.ndarray
        Image array of shape (H, W) or (H, W, C). Accepts uint8 or float.
    sigma : float
        Standard deviation of Gaussian noise in the same units as img.
        - If img is uint8 [0,255], use sigma like 10, 15, 25...
        - If img is float [0,1], use sigma like 0.02, 0.05, 0.1...
    clip : bool
        Whether to clip the result to the valid range (default: True).
    rng : np.random.Generator or None
        Optional random generator for reproducibility.

    Returns
    -------
    noisy : np.ndarray
        Noisy image, same dtype as input.
    """
    if rng is None:
        rng = np.random.default_rng()

    # Detect range and convert to float for safe addition
    orig_dtype = img.dtype
    if np.issubdtype(orig_dtype, np.integer):
        low, high = 0, np.iinfo(orig_dtype).max
        img_float = img.astype(np.float32)
    else:
        # Assume float image; infer min/max from data if needed
        # If your pipeline keeps it in [0,1], this is fine
        low, high = img.min(), img.max()
        img_float = img.astype(np.float32)

    noise = rng.normal(loc=0.0, scale=float(sigma), size=img.shape).astype(np.float32)
    noisy = img_float + noise

    if clip:
        # If dtype was integer, clip to [0, max]; if float, clip to [low, high]
        if np.issubdtype(orig_dtype, np.integer):
            noisy = np.clip(noisy, 0, np.iinfo(orig_dtype).max)
        else:
            # If you know your float images are [0,1], set low=0, high=1 instead
            noisy = np.clip(noisy, low, high)

    return noisy.astype(orig_dtype)

def add_salt_and_pepper_noise(img, amount=0.05, salt_vs_pepper=0.5, rng=None):
    """
    Add salt-and-pepper noise to an image (uint8 [0,255] or float [0,1]).

    Parameters
    ----------
    img : np.ndarray
        Image array of shape (H, W) or (H, W, C).
        - uint8: values in [0,255]
        - float: values in [0,1]
    amount : float
        Proportion of pixels to alter (e.g., 0.05 = 5% of pixels).
    salt_vs_pepper : float
        Ratio of salt (white) vs pepper (black). 0.5 means equal.
    rng : np.random.Generator or None
        Optional random generator for reproducibility.

    Returns
    -------
    noisy : np.ndarray
        Noisy image, same dtype as input.
    """
    if rng is None:
        rng = np.random.default_rng()

    noisy = img.copy()
    h, w = img.shape[:2]
    total_pixels = h * w
    num_salt = int(amount * total_pixels * salt_vs_pepper)
    num_pepper = int(amount * total_pixels * (1.0 - salt_vs_pepper))

    # Determine salt and pepper values based on dtype
    if np.issubdtype(img.dtype, np.integer):
        salt_value = np.iinfo(img.dtype).max  # 255 for uint8
        pepper_value = 0
    elif np.max(img) == 255 :
        salt_value = 255
        pepper_value = 0
    else:
        salt_value = 1.0
        pepper_value = 0.0

    #print(salt_value, pepper_value)
    
    # Salt (white pixels)
    coords = (rng.integers(0, h, num_salt), rng.integers(0, w, num_salt))
    if img.ndim == 2:  # grayscale
        noisy[coords] = salt_value
    else:  # color
        noisy[coords[0], coords[1], :] = salt_value

    # Pepper (black pixels)
    coords = (rng.integers(0, h, num_pepper), rng.integers(0, w, num_pepper))
    if img.ndim == 2:
        noisy[coords] = pepper_value
    else:
        noisy[coords[0], coords[1], :] = pepper_value

    return noisy


# def add_salt_and_pepper_noise(img, amount=0.05, salt_vs_pepper=0.5, rng=None):
#     """
#     Add salt-and-pepper noise to an image.

#     Parameters
#     ----------
#     img : np.ndarray
#         Image array of shape (H, W) or (H, W, C). Accepts uint8 or float.
#     amount : float
#         Proportion of pixels to alter (e.g., 0.05 = 5% of pixels).
#     salt_vs_pepper : float
#         Ratio of salt to pepper (0.5 = equal amounts).
#     rng : np.random.Generator or None
#         Optional random generator for reproducibility.

#     Returns
#     -------
#     noisy : np.ndarray
#         Noisy image, same dtype as input.
#     """
#     if rng is None:
#         rng = np.random.default_rng()

#     noisy = img.copy()
#     total_pixels = img.size // img.shape[-1] if img.ndim == 3 else img.size
#     num_salt = int(amount * total_pixels * salt_vs_pepper)
#     num_pepper = int(amount * total_pixels * (1.0 - salt_vs_pepper))

#     # Salt (max value)
#     coords_salt = tuple(rng.integers(0, i, num_salt) for i in img.shape[:2])
#     if img.ndim == 2:
#         noisy[coords_salt] = np.iinfo(img.dtype).max if np.issubdtype(img.dtype, np.integer) else 1.0
#     else:
#         noisy[coords_salt[0], coords_salt[1], :] = np.iinfo(img.dtype).max if np.issubdtype(img.dtype, np.integer) else 1.0

#     # Pepper (min value)
#     coords_pepper = tuple(rng.integers(0, i, num_pepper) for i in img.shape[:2])
#     if img.ndim == 2:
#         noisy[coords_pepper] = 0
#     else:
#         noisy[coords_pepper[0], coords_pepper[1], :] = 0

#     return noisy


def add_uniform_noise(img, low=-10, high=10, *, clip=True, rng=None):
    """
    Add uniform white noise to an image.

    Parameters
    ----------
    img : np.ndarray
        Image array of shape (H, W) or (H, W, C). Accepts uint8 or float.
    low : float
        Lower bound of the uniform noise range.
        - If img is uint8 [0,255], use something like low=-20, high=20.
        - If img is float [0,1], use low=-0.08, high=0.08.
    high : float
        Upper bound of the uniform noise range.
    clip : bool
        Whether to clip the result to the valid range (default: True).
    rng : np.random.Generator or None
        Optional random generator for reproducibility.

    Returns
    -------
    noisy : np.ndarray
        Noisy image, same dtype as input.
    """
    if rng is None:
        rng = np.random.default_rng()

    orig_dtype = img.dtype
    if np.issubdtype(orig_dtype, np.integer):
        low_clip, high_clip = 0, np.iinfo(orig_dtype).max
        img_float = img.astype(np.float32)
    else:
        low_clip, high_clip = img.min(), img.max()
        img_float = img.astype(np.float32)

    noise = rng.uniform(low, high, size=img.shape).astype(np.float32)
    noisy = img_float + noise

    if clip:
        noisy = np.clip(noisy, low_clip, high_clip)

    return noisy.astype(orig_dtype)


