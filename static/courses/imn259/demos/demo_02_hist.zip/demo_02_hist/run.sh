
for i in *.{pgm,ppm};
do
    python demo_hist.py $i
done



