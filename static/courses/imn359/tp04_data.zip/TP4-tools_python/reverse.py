
def reverse(x):
    """
        Reverse a vector.
    """
    return x[::-1]