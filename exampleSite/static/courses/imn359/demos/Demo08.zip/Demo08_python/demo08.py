import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat

from dct import dct
from idct import idct
from dct2 import dct2
from idct2 import idct2
from snr import snr

from scipy.fft import fft2, fftshift, ifftshift, ifft2

t1 = np.arange(0, 1+1/1000, 1 / 1000)  # ts = 0.001 seconde, fs = 1000
f1 = 8
T1 = 1 / f1  # frequence de 8 Hz
f2 = 3
T2 = 1/f2  # frequence de 3 Hz

s1 = np.cos(2 * np.pi * f1 * t1) + np.cos(2 * np.pi * f2 * t1)
dct_s1 = dct(s1)

fig, axs = plt.subplots(1, 2)

axs[0].plot(s1)
axs[1].plot(np.squeeze(dct_s1))
plt.show()

# LA DCT
t = np.arange(1, 101)
x = t + 50 * np.cos(t * 2 * np.pi / 40)
X = dct(x)

fig, axs = plt.subplots(1, 2)

axs[0].plot(x)
axs[1].plot(np.squeeze(X))
plt.show()

# Piece-regular
x0 = loadmat("piece-regular.mat")['x0']
X0 = np.abs(fft2(x0))
X0_shift = np.abs(fftshift(fft2(x0)))
fig, axs = plt.subplots(3, 1)
axs[0].plot(X0)
axs[0].set_title('fft of piece regular')
axs[1].plot(X0_shift)
axs[1].set_title('fft shifted of piece regular')
axs[2].plot(dct(x0))
axs[2].set_title('dct of piece regular')
plt.show()

n = 100
length = x0.shape[0]
xf = fftshift(fft2(x0))
xc = dct(x0)
x_compressed = np.zeros((x0.shape[0], 1), dtype=complex)
x_compressed[int(length/2) - 50:int(length / 2) + 50] = xf[int(length/2) - 50:int(length / 2) + 50]
x_compressed_fft = np.abs(ifft2(ifftshift(x_compressed)))

x_dct = np.zeros((length, 1))
x_dct[0:n] = xc[0:n].reshape((n, 1))

fig, axs = plt.subplots(3, 1)
axs[0].plot(x0)
axs[0].set_title('Piece-regular')
axs[1].plot(x_compressed_fft)
axs[1].set_title(str(n) + ' Fourier coeffs: erreur: ' +
                 str(np.linalg.norm(x_compressed_fft - x0)/np.linalg.norm(x0)*100)+ '%')
axs[2].plot(idct(x_dct))
axs[2].set_title(str(n) + ' DCT coeffs: erreur: ' +
                 str(np.linalg.norm(idct(x_dct) - x0)/np.linalg.norm(x0)*100)+ '%')
plt.show()

# In 2D
# Fourier classique
M = loadmat('lena.mat')['M']
n = M.shape[0]
m = int(n/8)
F = fftshift(fft2(M))
F1 = np.zeros_like(F, dtype=complex)
sel = np.array([n / 2 - m / 2, n / 2 + m / 2 + 1], dtype=int)
F1[sel[0] : sel[1], sel[0] : sel[1]] = F[sel[0] : sel[1], sel[0] : sel[1]]
f1 = np.real(ifft2(fftshift(F1)))

fig, axs = plt.subplots(2, 1)
axs[0].imshow(M)
axs[0].set_title('Image')
axs[1].imshow(f1)
axs[1].set_title('Approx, SNR= ' + str(snr(M, f1)) + ' dB')
plt.show()

# DCT 2D
Mc = dct2(M)
fig, axs = plt.subplots(2, 1)
axs[0].imshow(np.log(np.abs(Mc)))
axs[1].imshow(np.log(np.abs(F)))
plt.show()

f2 = np.zeros((n,n))
f2[0:m, 0:m] = Mc[0:m, 0:m]
f2 = idct2(f2)

fig, axs = plt.subplots(2, 1)
axs[0].imshow(f1)
axs[0].set_title('Fourier Approx' + str(m**2) + ' coeffs, SNR= ' + str(snr(M, f1)) + ' dB')
axs[1].imshow(f2)
axs[1].set_title('DCT Approx' + str(m**2) + ' coeffs, SNR= ' + str(snr(M, f2)) + ' dB')
plt.show()

# DCT locale
######################################################
# Approximation avec des cosinus locaux
# 
# Ameliore l'approximation globale de la DCT
# On decoupe le signal en segments locaux  dans lesquels on
# fait la DCT
# JPEG est basée sur cette base
# ####################################################

x0 = loadmat('piece-regular.mat')['x0']
n = x0.shape[0]
fc = dct(x0)
f1 = idct(fc)
coeff = 192
fm = np.zeros((n, 1))
fm[0:coeff] = fc[0:coeff]
fm = idct(fm)

w = 32 # taille du segment

fc_a = np.zeros((n, 1))

# DCT locale
for i in range(int(n/w)):
    seli = np.array([i * w, i * w + w])
    fc_a[seli[0]:seli[1]] = dct(x0[seli[0]:seli[1]])

fig, axs = plt.subplots(2, 1)
axs[0].plot(np.abs(fc))
axs[1].plot(np.abs(fc_a))
plt.show()

# We have bins of w units, so n/w bins over the signal f with n units. This
# means that if we want to keep coeff coefficients, we keep coeff/(n/w) lowest frequency
# coefficients in each bin

# iDCT locale
fm_local = fc_a
fc_a_4 = np.zeros((n, 1))
fm_a = np.zeros((n, 1))

s = int(coeff / (n / w))
for i in range(int(n/w)):
    seli = np.array([i * w, i * w + w])
    sela = np.array([i * w, i * w + s])
    fc_a_4[sela[0]:sela[1]] = fm_local[sela[0]:sela[1]]
    fm_local[seli[0]:seli[1]] = idct(fm_local[seli[0]:seli[1]])
    fm_a[seli[0]:seli[1]] = idct(fc_a_4[seli[0]:seli[1]])

f = x0
print('Error |f-f1|/|f| using a full Discrete Cosine basis = ', np.linalg.norm(f-f1)/np.linalg.norm(f))
print('Error |f-f1|/|f| using a full local Discrete Cosine basis = ', np.linalg.norm(f-fm_local)/np.linalg.norm(f))
print('Error |f-f1|/|f| using  ' + str(coeff) + ' DCT coeffs = ', np.linalg.norm(f-fm)/np.linalg.norm(f))
print('Error |f-fm|/|f| using ' + str(coeff) + ' local DCT coeffs = ', np.linalg.norm(f-fm_a)/np.linalg.norm(f))

fig, axs = plt.subplots(3, 1)
axs[0].plot(fm_local)
axs[0].set_title('Signal from full local DCT reconstruction')
axs[1].plot(fm)
axs[1].set_title('Approximation from ' + str(coeff) + ' DCT coefficients')
axs[2].plot(fm_a)
axs[2].set_title('Approximation from ' + str(coeff) + ' DCT coefficient with segments of size ' + str(w))
plt.show()


#################
# Plus agressif
#################

coeff = 128
fm = np.zeros((n, 1))
fm[0:coeff] = fc[0:coeff]
fm = idct(fm)

w = 8

fc_a = np.zeros((n, 1))

# DCT locale
for i in range(int(n/w)):
    seli = np.array([i * w, i * w + w])
    fc_a[seli[0]:seli[1]] = dct(x0[seli[0]:seli[1]])

fig, axs = plt.subplots(2, 1)
axs[0].plot(np.abs(fc))
axs[1].plot(np.abs(fc_a))
plt.show()

# We have bins of 16 units, so 64 bins over the signal f with n = 1024. This
# means that if we want to keep 256 coefficients, we keep 4 lowest frequency
# coefficients in each bin

# iDCT locale
fm_local = fc_a
fc_a_4 = np.zeros((n, 1))
fm_a = np.zeros((n, 1))

s = int(coeff / (n / w))
for i in range(int(n/w)):
    seli = np.array([i * w, i * w + w])
    sela = np.array([i * w, i * w + s])
    fc_a_4[sela[0]:sela[1]] = fm_local[sela[0]:sela[1]]
    fm_local[seli[0]:seli[1]] = idct(fm_local[seli[0]:seli[1]])
    fm_a[seli[0]:seli[1]] = idct(fc_a_4[seli[0]:seli[1]])

f = x0
print('Error |f-f1|/|f| using a full Discrete Cosine basis = ', np.linalg.norm(f-f1)/np.linalg.norm(f))
print('Error |f-f1|/|f| using a full local Discrete Cosine basis = ', np.linalg.norm(f-fm_local)/np.linalg.norm(f))
print('Error |f-f1|/|f| using  ' + str(coeff) + ' DCT coeffs = ', np.linalg.norm(f-fm)/np.linalg.norm(f))
print('Error |f-fm|/|f| using ' + str(coeff) + ' local DCT coeffs = ', np.linalg.norm(f-fm_a)/np.linalg.norm(f))

fig, axs = plt.subplots(3, 1)
axs[0].plot(fm_local)
axs[0].set_title('Signal from full local DCT reconstruction')
axs[1].plot(fm)
axs[1].set_title('Approximation from ' + str(coeff) + ' DCT coefficients')
axs[2].plot(fm_a)
axs[2].set_title('Approximation from ' + str(coeff) + ' DCT coefficient with segments of size ' + str(w))
plt.show()
