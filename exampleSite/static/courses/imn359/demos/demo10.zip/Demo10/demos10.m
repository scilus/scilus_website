load cameraman_pyramid.mat


% Pyramid representation of the cameran man
% Each resize was obtained with a bicubic interpolation

subplot(2,4,1);
imagesc(f); colormap(gray);  axis image; title('Original image 512x512');

subplot(2,4,2);
imagesc(f1); colormap(gray);  axis image; title('Original image 256x256');


subplot(2,4,3);
imagesc(f2); colormap(gray);  axis image; title('Original image 128x128');


subplot(2,4,4);
imagesc(f3); colormap(gray);  axis image; title('Original image 64x64');


subplot(2,4,5);
imagesc(f4); colormap(gray);  axis image;  title('Original image 32x32');

subplot(2,4,6);
imagesc(f5); colormap(gray);  axis image;  title('Original image 16x16');

subplot(2,4,7);
imagesc(f6); colormap(gray);  axis image;  title('Original image 8x8');

subplot(2,4,8);
imagesc(f7); colormap(gray);  axis image; title('Original image 4x4');


%%% 
n = 512;
mu = 5;
% compute a Gaussian filter of width mu
t = (-n/2:n/2-1)';
h = exp( -(t.^2)/(2*mu^2) );
h = h/sum(h(:));
plot(t,h);
fhy = conv2(f,h,'same');
fh = conv2(fhy,h','same');
% display
clf;
subplot(1,2,1); imagesc(f); colormap(gray);  axis image; axis off; title('Original image');
subplot(1,2,2); imagesc(f-fh); colormap(gray);  axis image; axis off; title('Laplacian representation level 0');


%%% Vous pouvez le faire a tous les niveaux maintenant

